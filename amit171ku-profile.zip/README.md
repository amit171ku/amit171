![Intro](./assets/hero.svg?v=1)

![About](./assets/about-life.svg?v=1)

![Stack](./assets/stack.svg?v=1)

![ID](./assets/id-dashboard.svg?v=1)

## Featured projects

| Project | What it does | Stack |
|---|---|---|
| [Spam Classifier](https://github.com/amit171ku/spam-classifier) | Email threat detection with a hybrid ML + rule-based approach (Naive Bayes + TF-IDF). Detects spam, phishing and promotional emails. Deployed on Render. | Python, FastAPI, React, scikit-learn |
| [AI Inventory System](https://github.com/amit171ku/AI-inventory-System) | AI-powered inventory management with smart stock tracking. | Python |
<!-- RAG Chatbot row: add repo URL, what it answers over, and its stack, then uncomment
| [RAG Chatbot](URL) | DESCRIPTION | STACK |
-->

![Connect](./assets/connect.svg?v=1)

**Connect:** [LinkedIn](https://www.linkedin.com/in/amit-sharma174) · [GitHub](https://github.com/amit171ku)
